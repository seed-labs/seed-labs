# Python3.12 is already in the OS
echo "Installing Python and modules ..."

# Install pip3 and Python3 modules 
sudo apt install -y python3-venv python3-pip build-essential python3-scapy
# sudo pip3 install scapy
# sudo pip3 install pycryptodome