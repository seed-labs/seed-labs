from flask import Flask, Response, render_template

app = Flask(__name__)

@app.route("/benign")
def benign():
    resp = Response()
    resp.data = render_template('benign.html')

    # TODO: Task 5

    return resp
